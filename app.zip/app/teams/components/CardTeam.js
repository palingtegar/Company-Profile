import Image from "next/image";
import React from "react";

const CardTeam = ({ team }) => {
  return (
    <div>
      <Image
        src={team.picture.large}
        alt={`photo ${team.name.first}`}
        width={200}
        height={200}
      />
      <h1 className="font-bold">{team.name.first}</h1>
    </div>
  );
};

export default CardTeam;

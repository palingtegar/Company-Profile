import Image from "next/image";
import React from "react";
import CardTeam from "./components/CardTeam";

const Teams = async () => {
  const response = await fetch(
    "https://randomuser.me/api/?results=8&nat=in&gender=female"
  );
  const { results } = await response.json();

  console.log(results);

  return (
    <div>
      <h1>Teams</h1>
      <br />
      <br />
      {results.map((team, index) => {
        return <CardTeam key={index} team={team} class />;
      })}
    </div>
  );
};

export default Teams;
